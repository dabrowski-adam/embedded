#define RD (1<<16)
#define WR (1<<17)
#define A0 (1<<18)
#define RES (1<<19)
#define CS1 (1<<20)
#define test (1<<23)
void delay (void);
void wr_lcd_bus(unsigned char data);
unsigned char rd_lcd_bus(void);
void lcd_write_data(unsigned char data);
void lcd_write_cmd(unsigned char cmd);
unsigned char lcd_read_data(void);
unsigned char lcd_read_status(void);
void lcd_init_hwd();
void lcd_init(void);
void Poz(char x, char y);
void DispLcd(const char *napis,char x,char y);
void WriteChar(char code);
void clr_display_ram(void);
void send_bmp(void);
