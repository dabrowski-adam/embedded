#include <LPC214x.h>
#include "lcd.h"

int main (void){

 		lcd_init();
		send_bmp();
	
	lcd_write_cmd(0xd5);
	lcd_write_cmd(0);
	//	while(1);
 
		DispLcd(" Test wyswietlacza ",0,1);
		DispLcd("LEADER TIME LT13264 ",0,2);
		DispLcd("matryca LCD 132x64",0,3);
		DispLcd(" sterownik SPLC501C",0,4);
		DispLcd("   Tryb tekstowy  ",0,5);
		DispLcd(" znaki 6x8 pikseli",0,6);

 while(1);
}
void clr_display_ram(void){
char i,j;
	lcd_write_cmd(0x40);//display start line =0;
	for(i=0;i<9;i++)
 	{lcd_write_cmd(0xb0+i);//adres strony
	lcd_write_cmd(0x10);//adres kolumny - starsza czesc
	lcd_write_cmd(0x00);//adres kolumny mlodsza czesc  
	for (j=0;j<132;j++)
	 lcd_write_data(0);
	}
}
void lcd_init(void){
 	lcd_init_hwd();
	IOCLR1|=test;
	//lcd_write_cmd(0xa2); //bias 1/9 domyslnie ustawiony po reset
	lcd_write_cmd(0xa0);//ADC normal
	lcd_write_cmd(0xa7);//display normal/inverse
	lcd_write_cmd(0xc8);//common output - reverse

	lcd_write_cmd(0x81);
	lcd_write_cmd(0x2f);//electronic volume set
	lcd_write_cmd(0x23);//V5 voltage regulator
	lcd_write_cmd(0x2f);//zalaczenie przetwornicy
	clr_display_ram();//zerowanie pamieci wyswietlacza 
	lcd_write_cmd(0xaf);//wlaczenie wyswietlacza 
	//lcd_write_cmd(0x4c);
	


}
void lcd_init_hwd(){
int i;
for(i=0;i<100;i++)
	delay();
	IO1DIR=0x00FF0000;//linie sterujace jako wyjscia
	IOCLR1=0;
	IOSET1=0;
	IOSET1|=WR;//te linie w stan wysoki
	IOSET1|=RD;
	IOSET1|=A0;
	IOSET1|=CS1;
	IOCLR1|=RES;//reset wyswietlacza aktywny
	for(i=0;i<8000;i++)
	delay();
	IOSET1|=RES;//reset nieaktywny
	while((lcd_read_status()&0x10)==0x10);//czekaj na wykonanie sie zerowania
}
//zapisanie danej do sterownika 
void lcd_write_data(unsigned char data){
   
 	IOSET1|=A0;	delay();//linia A0=1 - zapisanie danej
	IOSET1|=RD; delay();//linia RD=1 
	wr_lcd_bus(data);//zapisanie na magistrale
}
//zapisanie komendy do sterownika
void lcd_write_cmd(unsigned char cmd){ 
 	 IOCLR1|=A0;	delay();//linia A0=0 - zapisanie komendy 
	 IOSET1|=RD;    delay();//linia RD=1 
	 wr_lcd_bus(cmd);//zapisanie na magistrale
}
//odczytanie danej z magistrali
unsigned char lcd_read_data(void){
 	 IOCLR1|=A0;	delay();//linia A0=0 - odczytanie danej
	 IOSET1|=WR; 	delay();//WR=1 
	 return(rd_lcd_bus());
}
//odczytanie statusu z magistrali
unsigned char lcd_read_status(void){
 	 IOSET1|=A0;  delay();//linia A0=1 - odczytanie satusu 
	 IOSET1|=WR;  delay();//WR=1
	 return(rd_lcd_bus());
}
//odczytanie danych z magistrali
unsigned char rd_lcd_bus(void){
unsigned char data;
 	 IO0DIR&=0xff00ffff;//bity P0.16....P023 wejscie
	 IOCLR1|=CS1; delay();//linia CE=0
	 IOCLR1|=RD; delay();  delay();
	 data=(IOPIN0>>16);//odczytaj dane 
	 IOSET1|=RD; delay();//RD=1
	 IOSET1|=CS1; delay();//CE=1
	 return(data);
}
//zapisanie danej na magistrale 
//linie danych P0.16...P0.23
void wr_lcd_bus(unsigned char data){
	IOSET1|=CS1; delay();//CS1=1
	IO0DIR|=(0xff<<16);//bity P0.16....P023 wyjscie
	int temp=(data<<16);
	IOCLR0=0x00ff0000;//zeruj bity P0.16...P0.23
	delay();
	IOSET0=temp;//dane na swoim miejscu	
	delay();
	IOCLR1|=CS1; delay();//linia CS1=0
	IOCLR1|=WR; delay();  delay();  delay();//WR=0 - zapisanie danej
	IOSET1|=WR; delay();//WR=1
	IOSET1|=CS1; delay();//CE=1
}
extern const unsigned char bmp[];
void send_bmp(void){
unsigned char i,j;
	
		for(j=0;j<8;j++){
		lcd_write_cmd(0);//set lower column address
	    lcd_write_cmd(0x10);//set higer column address
		lcd_write_cmd(0xb0+j);//set page 
		for(i=0;i<132;i++)
		lcd_write_data(bmp[i+j*128]);
		}

}
void delay (void){ 
  unsigned int i;  
  for(i = 0; i < 0x20; i++);	   
}

