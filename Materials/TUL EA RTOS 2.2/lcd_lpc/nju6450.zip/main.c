#include <lpc214x.h>
#include "fun.h"
//definicja linii ster wyswietlacza
#define E1 1<<17
#define E2 1<<18
#define RW 1<<19
#define A0 1<<16 
#define RES 1<<20
#define IC1 0
#define IC2 1
int main (void){
	
	IO0DIR=0x00FF0000;//linie sterujace jako wyjscia
	IOCLR1=0;
	IOSET1=0;
	IOCLR0|=RES;
	delay();delay();
	IOSET0|=RES;
	LcdWriteCmd(0xae,IC1);//wylacz wyswietlacz
	LcdWriteCmd(0xae,IC2);//wylacz wyswietlacz
	LcdWriteCmd(0xa0,IC1);//tryb normal
	LcdWriteCmd(0xa0,IC2);//tryb normal
	LcdWriteCmd(0xa4,IC1);//dynamic drive
	LcdWriteCmd(0xa4,IC2);//dynamic drive
	LcdWriteCmd(0xa9,IC1);//1/32 duty
	LcdWriteCmd(0xa9,IC2);//1/32 duty
	LcdCls();
	LcdWriteCmd(0xaf,IC1);//wlacz wyswietlacz
	LcdWriteCmd(0xaf,IC2);//wlacz wyswietlacz

	//LcdBmp();
	LcdTxt("  test wyswietlacza",0,0);
	LcdTxt("  HY-12232  matryca",0,1);
	LcdTxt("   122x32 piksele" ,0,2);
	LcdTxt("   tryb tekstowy   ",0,3);

	//LcdBmp();
	while(1);
}
void LcdOn(void){
	LcdWriteCmd(0xaf,IC1);//wlacz wyswietlacz
	LcdWriteCmd(0xaf,IC2);//wlacz wyswietlacz
}
void LcdCls(void){
char i,j;
	for(j=0;j<4;j++){
	for(i=0;i<122;i++)
	LcdWriteData(0,i,j);
	}
}
//zapisanie polecenia do obu chip'ow
void LcdWriteCmd(unsigned char cmd,unsigned char chip){
	if(chip==IC1)
	while(CheckBusy(IC1));
	if(chip==IC2)
	while(CheckBusy(IC2));
	IOCLR0|=A0;delay();//zapisywanie polecenia
	if(chip==IC1)
	LcdBusWrite(cmd,IC1);
	if(chip==IC2)
	LcdBusWrite(cmd,IC2);
}
void LcdWriteData(unsigned char data, unsigned char column, unsigned char page){
 	page&=3;
	if(column>60)
	LcdWriteCmd(page|0xb8,IC2);//adres strony
	else
	LcdWriteCmd(page|0xb8,IC1);//adres strony
	LcdColumnSet(column);//numer kolumny	

	if(column>60)
	{while(CheckBusy(IC2));
	IOSET0|=A0;delay();//zapisanie danej 
	LcdBusWrite(data,IC2);//zapisanie danej do ukladu IC1
	}
	else
	{while(CheckBusy(IC1));
	IOSET0|=A0;delay();//zapisanie danej 
	LcdBusWrite(data,IC1);//zapisanie danej do ukladu IC2
	}
}
//zapisanie licznika kolumn
void LcdColumnSet(unsigned char column){
    
 	if(column>60){
	while(CheckBusy(IC2));
	IOCLR0|=A0;delay();//zapisywanie polecenia
	LcdBusWrite(column-61,IC2);}

	else{
	while(CheckBusy(IC1));
	IOCLR0|=A0;delay();//zapisywanie polecenia
	LcdBusWrite(column,IC1);}
}
unsigned char  CheckBusy(unsigned char chip){
unsigned char data;
	 IOCLR0|=E1;delay();//E1=0
	 IOCLR0|=E2;delay();//E2=0
	 IOSET0|=RW;delay();//RW=1
	 IOCLR0|=A0;delay();//czytaj status
	 if(chip==IC1)
	 IOSET0|=E1;delay();
	 if(chip==IC2)
	 IOSET0|=E2;delay();
	 IO1DIR&=0xff00ffff;//bity P0.16....P023 wejscie	 
	 data=(IOPIN1>>16);//odczytaj dane 
	 IOCLR0|=E1;delay();//E1=0
	 IOCLR0|=E2;delay();//E2=0
	 return(data>>7);

}
void LcdBusWrite(unsigned char data, unsigned char chip){	
	IOCLR0|=E1;delay();//E1=0
	IOCLR0|=E2;delay();//E2=0
	if(chip==IC1)
	IOSET0|=E1;delay();
	if(chip==IC2)
	IOSET0|=E2;delay();
    
	IOCLR0|=RW;delay();//RW=0 zapis danej 
	IO1DIR|=(0xff<<16);//bity P1.16....P1.23 wyjscie
	int temp=(data<<16);
	IOCLR1=0x00ff0000;delay();//zeruj bity P1.16...P1.23
	IOSET1=temp; delay();delay();//dane na swoim miejscu

	IOCLR0|=E1;delay();//E1=0
	IOCLR0|=E2;delay();//E2=0
	delay();
}
void delay(void){
int i;
	for(i=0;i<50;i++)
	;
}
