#include <LPC214x.h>
//definicja linii interfejsu
#define RES 1<<8
#define CS 1<<7
#define DATA 1<<6
#define CLK 1<<4

#define Cmd		0 //komendy sterownika
#define Data	1 //dane sterownika

#define BLACK   255
#define WHITE   0
#define RED     31
#define GREEN   227
#define BLUE    249	//252
#define YELLOW    11 //(11)


#define  LCD_DX		98
#define  LCD_DY		67

void Cls(char color);
void Delay(void);
void lcd_init(void);
void LcdChar(char zn, char x, char y, char chc, char bckc);
void SendLcd(unsigned char dana, unsigned char cmd);
void DispTxt(const char *napis,char x,char y,char chc,char bckc);
void LcdBmp(const unsigned char *buff, char x, char y, char chc, char bckc);
void LcdDig(unsigned char dig,char x, char y, char chc, char bckc);
void full_color_bmp();
													
