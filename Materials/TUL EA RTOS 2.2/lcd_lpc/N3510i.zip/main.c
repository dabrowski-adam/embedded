#include <LPC214x.h>
#include "33510i.h"
extern const char rom_gen[];
extern const unsigned char bmp[562];
extern const unsigned char cisn[158];
extern const unsigned char tw[148];
extern const unsigned char tz[158];
extern const unsigned char h[158];
extern const unsigned char z[158];
int main(void){
char i,j ;
int k;

	IO0DIR|=CS;
	IO0DIR|=RES;
	IO0DIR|=DATA;
	IO0DIR|=CLK;
	lcd_init();
	Cls(BLACK);
	full_color_bmp();
	while(1);
	i=WHITE;
	
	LcdBmp(cisn,0,26,WHITE,RED);	
	LcdDig(1,20,26,WHITE,RED);
	LcdDig(0,30,26,WHITE,RED);
	LcdDig(0,40,26,WHITE,RED);
	LcdDig(5,50,26,WHITE,RED);

	LcdBmp(tw,0,0,WHITE,123);
	LcdDig(2,33,0,WHITE,123);
	LcdDig(2,43,0,WHITE,123);
	LcdDig(5,58,0,WHITE,123);

	LcdBmp(tz,0,13,BLUE,YELLOW);
	LcdDig(0,33,13,BLUE,YELLOW);
	LcdDig(2,43,13,BLUE,YELLOW);
	LcdDig(5,58,13,BLUE,YELLOW);

	LcdBmp(h,0,39,BLACK,GREEN);
	LcdDig(3,28,39,BLACK,GREEN);
	LcdDig(2,38,39,BLACK,GREEN);

	LcdBmp(z,0,52,WHITE,BLUE);
	LcdDig(2,5,52,WHITE,BLUE);
	LcdDig(0,15,52,WHITE,BLUE);	
	LcdDig(1,30,52,WHITE,BLUE);
	LcdDig(1,40,52,WHITE,BLUE);
	LcdDig(1,55,52,WHITE,BLUE); 
	LcdDig(7,65,52,YELLOW,BLUE); 
	 
	   //while(1);
	while(1){
	j=BLUE;
	i=WHITE;  
	//lcd_char('T',0,1, BLACK, RED);
	//lcd_char('o',6,1, BLACK, RED);
	DispTxt("   WYSWIETLACZ  ",0,0,j,i);
	DispTxt("  od telefonu   ",0,1,j,i);
	DispTxt("   Nokia 3510i  ",0,2,j,i);
	DispTxt(" test w trybie  ",0,3,j,i);
	DispTxt("   graficznym   ",0,4,j,i);
	DispTxt("ZL9ARM + LPC2148",0,5,j,i);
	DispTxt("      BTC       ",0,6,j,i);
	DispTxt("   www.btc.pl   ",0,7,j,i);
	while(1);
	for(k=0;k<10;k++)
	Delay();
	i=WHITE;
	j=BLACK; 

	DispTxt("   CISNIENIE    ",0,0,j,i);
	DispTxt("     997 hPa    ",0,1,j,i);
	DispTxt("TEMPERATURA WEWN",0,2,j,i);
	DispTxt("     +23.3C     ",0,3,j,i);
	DispTxt("TEMPERATURA ZEWN",0,4,j,i);
	DispTxt("    +03.3C      ",0,5,j,i);
	DispTxt("   WILGOTNOSC   ",0,6,j,i);
	DispTxt("     18.4%      ",0,7,j,i);
	for(k=0;k<10;k++)
	Delay();
	}
	while(1);
}



void lcd_init(){
   
	IOSET0|=CS;//CS=1
	IOSET0|=CLK;//CLK=1
	IOSET0|=DATA;//Data=1

//Faza1  LCD Hardware Reset
    
	IOCLR0|=RES;//RES=0 sprzetowy reset sterownika
    Delay();
	IOSET0|=RES;//RES=1
    Delay();
    
    SendLcd(0x01, Cmd);// LCD Software Reset
    Delay();
    
    SendLcd(0xC6, Cmd);        // Initial Escape
    Delay();

//*** phase 2: display setup 1
    SendLcd(0xB9, Cmd);        // Refresh set
    SendLcd(0x00, Data);
    
    SendLcd(0xB6, Cmd);        // Display Control
    SendLcd(128, Data);
    SendLcd(128, Data);        //no N line inversion
    SendLcd(0x81, Data);        //frame freq; bias rate of LCD drive voltage; 98x67; diplay duty=1/67; 
    SendLcd(84, Data);
    SendLcd(69, Data);
    SendLcd(82, Data);
    SendLcd(67, Data);
    
    SendLcd(0xB3, Cmd);        // Gray Scale Position
    SendLcd(0x11, Data);
    SendLcd(0x22, Data);
    SendLcd(0x33, Data);
    SendLcd(0x44, Data);
    SendLcd(0x55, Data);
    SendLcd(0x66, Data);
    SendLcd(0x77, Data);
    SendLcd(0x88, Data);
    SendLcd(0x99, Data);
    SendLcd(0xAA, Data);
    SendLcd(0xBB, Data);
    SendLcd(0xCC, Data);
    SendLcd(0xDD, Data);
    SendLcd(0xEE, Data);
    SendLcd(0xFF, Data);
    
    SendLcd(0xB5, Cmd);        // Gamma Curve Set
    SendLcd(1, Data);

    SendLcd(0xBD, Cmd);        // Common driver setup
    SendLcd(0, Data);

//*** phase 3: power supply
    SendLcd(0xBE, Cmd);        // Power Control
    SendLcd(4, Data);
    
    SendLcd(0x11, Cmd);        // Sleep out
    
    SendLcd(0xBA, Cmd);        // Voltage control
    SendLcd(63, Data);
    SendLcd(3, Data);
    
    SendLcd(0x25, Cmd);        // Write contrast
    SendLcd(45, Data);		   //69

    SendLcd(0x2D, Cmd);        // Colour set (only for 8-bit/pixel)
    SendLcd(0x00, Data);       // RED
    SendLcd(0x02, Data);
    SendLcd(0x04, Data);
    SendLcd(0x06, Data);
    SendLcd(0x09, Data);
    SendLcd(0x0b, Data);
    SendLcd(0x0d, Data);
    SendLcd(0x0f, Data);
    SendLcd(0x00, Data);       // GREEN
    SendLcd(0x02, Data);
    SendLcd(0x04, Data);
    SendLcd(0x06, Data);
    SendLcd(0x09, Data);
    SendLcd(0x0b, Data);
    SendLcd(0x0d, Data);
    SendLcd(0x0f, Data);
    SendLcd(0x00, Data);       // BLUE
    SendLcd(0x05, Data);
    SendLcd(0x0a, Data);
    SendLcd(0x0f, Data);
    
    SendLcd(0xB7, Cmd);        // Temperature gradient set
    SendLcd(0, Data);
    SendLcd(0, Data);
    SendLcd(0, Data);
    SendLcd(0, Data);
    SendLcd(0, Data);
    SendLcd(0, Data);
    SendLcd(0, Data);
    SendLcd(0, Data);
    SendLcd(0, Data);
    SendLcd(0, Data);
    SendLcd(0, Data);
    SendLcd(0, Data);
    SendLcd(0, Data);
    SendLcd(0, Data);
    
    SendLcd(0x03, Cmd);        // Booster Voltage ON
    Delay();
	Delay();
	Delay();
	Delay();
    
//*** phase 4: display setup 2
    SendLcd(0x20, Cmd);        // Inversion control (OFF)
    
//*** phase 5: display setup 3
    SendLcd(0x3A, Cmd);        // 8bpp
    SendLcd(0x02, Data);

    SendLcd(0x29, Cmd);        // Display On
}

void PosChar(char x, char y)
{ 
	x=(x*6);
	y=(y*8);
	SendLcd(0x2A, Cmd);        // ustawienie adresu w kolumnie
  	SendLcd(x+1, Data);          // Start
  	SendLcd(x+6,Data);  // End
  	SendLcd(0x2B, Cmd);        // Page adress set
  	SendLcd(y,Data);           // Start
  	SendLcd(y+7,Data);  // End
}
void DispTxt(const char *napis,char x,char y,char chc,char bckc)
{	
	SendLcd(0x36, Cmd);        // 
    SendLcd(0x20, Data);       //tryb adresowania na pionowy 

    while(*napis!=0)	
	{ PosChar(x,y);//pozycja tekstu na wyswietlaczu
	  LcdChar(*napis,x,y,chc,bckc);
	 ++x;//nastepny znak 
	 if(x>15)
	 {x=0;
	  ++y;}
    ++napis;}
} 

void LcdChar(char zn, char x, char y, char chc, char bckc) { 
 char i,wz,k;
 int j;
  j=zn*6;//poczatkowa pozycja w generztorze znak�w
  SendLcd(0x2C, Cmd);//komenda zapisywania pamieci RAM
  for(k=0;k<6;k++){
  wz=rom_gen[j];
  for(i=0;i<8;i++)
  {if((wz&1)==1)
    SendLcd(chc,Data); 
	else
	SendLcd(bckc,Data);
	wz=(wz>>1);
	}
	++j;
	}


}
void Cls(char color) { 
  int i;
  SendLcd(0x36, Cmd);        // x,y=0
  SendLcd(0x20, Data);       // Page direction in writing
  SendLcd(0x2A, Cmd);        // Column adress set
  SendLcd(0, Data);          // Start
  SendLcd((LCD_DX-1),Data);  // End
  SendLcd(0x2B, Cmd);        // Page adress set
  SendLcd(0,Data);           // Start
  SendLcd((LCD_DY-1),Data);  // End
  SendLcd(0x2C, Cmd);        // Memory Write
  for(i=0;i<LCD_DX*LCD_DY;i++)
  
    SendLcd(color,Data); 
  SendLcd(0x36, Cmd);  // x,y=0
  SendLcd(0x20,Data);
}
void SendLcd(unsigned char data, unsigned char cmd){
    unsigned char i;
    
	IOCLR0|=CS;//CS=0
	IOCLR0|=CLK;//CLK=0
    
	//pierszy bit okresla czy przeylana sa dane czy komendy 
    if(cmd==Cmd)
	 IOCLR0|=DATA;//DATA=0 
	else 
	IOSET0|=DATA;//Data=1
  
	IOSET0|=CLK;//CLK=1 wpisanie D/C
    for (i=0;i<8;i++) {
		IOCLR0|=CLK;//CLK=0
        if ((data&0x80)==0)
		 IOCLR0|=DATA;//Data=0
		 else 
		 IOSET0|=DATA;
		IOSET0|=CLK;//CLK=1 
        data<<=1;
    }
	IOSET0|=CS;
}
void Delay(void){
int i;
	for(i=0;i<0xfffff;i++)
	;

}

