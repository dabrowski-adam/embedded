#include <LPC214x.H>
#include "t6963.h"
void led_disp(char data);
extern const unsigned char screen[];
extern const unsigned char play[];
extern const unsigned char stop[];
extern const unsigned char fwd[];
extern const unsigned char rev[];
extern const unsigned char time[];
extern const unsigned char track[];
extern const unsigned char total[];
const unsigned char gen_ram_char[8]={0,4,0x0e,0x15, 4,4,4,0};
int main(void){

	lcd_hwd_init();
	lcd_init();
	//display_text("TEST",12,1);
	//display_char(0x80,12,2);

	send_icon_ram(screen,0,0);
	while(1);
	send_icon_ram(track,19,12);
	send_icon_ram(total,19,24);
	send_icon_ram(time,19,36);

	send_char_ram(0,25,12);
	send_char_ram(4,26,12);

	send_char_ram(1,24,24);
	send_char_ram(0,25,24);
	send_char_ram(10,26,24);
	send_char_ram(5,27,24);
	send_char_ram(0,28,24);

	send_char_ram(0,24,36);
	send_char_ram(5,25,36);
	send_char_ram(10,26,36);
	send_char_ram(3,27,36);
	send_char_ram(7,28,36);
	
	 send_icon_ram(play,2,34);
	 while(1)anim_play(1,7,100000);
	
}

void display_text(const char *buffer,char x,char y){
int pos;
	pos=TA+((y-1)*30)+x;
	lcd_write_2cmd(pos>>8,pos,0x24);//address pointer set 												  	
	while((*buffer)!='\0'){
	lcd_write_1cmd((*buffer++)-0x20,0xc0);
	}
}
void display_char(char ram_char, char x, char y){
int pos;
	pos=TA+((y-1)*30)+x;
	lcd_write_2cmd(pos>>8,pos,0x24);//address pointer set 												  	
	lcd_write_1cmd(ram_char,0xc0);//wpisz do pamieci TA kod wczesniej zdefiniowanego znaku 
}
void init_CGRAM(void){
char i;
const unsigned char *char_gen;
	char_gen=gen_ram_char;
	lcd_write_2cmd(0x2c,0x00,0x24);//pointer 0x2c00
	lcd_write_0cmd(0xb0);//data auto write
	for(i=0;i<8;i++){
	while((lcd_read_status()&8)!=8);//czekaj na gotowosc wpisania polecenia  
	lcd_write_data(*char_gen++);
	}
	lcd_write_0cmd(0xb2);//reset auto write
}
void lcd_init(void){
int area;
	lcd_write_0cmd(0x80);//OR CG ROM mode
	area=GA;
	lcd_write_2cmd(area>>8,area,0x42);//GH=00
	lcd_write_2cmd(0,30,0x43);//graphic area 30*8=240 dla znak�w 6x8 pixel
	area=TA;
	lcd_write_2cmd(area>>8,area,0x40);//text home address= 0x2000
	lcd_write_2cmd(0,30,0x41);//text area 30*8=240
	lcd_write_2cmd(0,5,0x22);//offset text VRAM = 0x2800
	init_CGRAM();
	init_text_ram();//inicja,izacja pamieci ram text
	init_graph_ram(0);
  	lcd_write_0cmd(0x9c);//display ON
}
//inicjalizacja zawartosci pamieci ram txt
void init_text_ram(void){
int i;
	i=TA;//poczatek onszaru VRAM tekstu
	lcd_write_2cmd(i>>8,i,0x24);//address pointer set 
	lcd_write_0cmd(0xb0);//data auto write
	for(i=0;i<300;i++){
	while((lcd_read_status()&8)!=8);//czekaj na gotowosc wpisania polecenia  
	lcd_write_data(0);
	}
	lcd_write_0cmd(0xb2);//reset auto write
}
void init_graph_ram(char fill){
int i;
	i=GA;//poczatek obszaru VRAM grafiki
	lcd_write_2cmd(i>>8,i,0x24);//address pointer set 
	lcd_write_0cmd(0xb0);//data auto write
	for(i=0;i<2000;i++){
	while((lcd_read_status()&8)!=8);//czekaj na gotowosc wpisania polecenia  
	lcd_write_data(fill);
	}
	lcd_write_0cmd(0xb2);//reset auto write
}
void lcd_write_0cmd(unsigned char cmd){
	while((lcd_read_status()&3)!=3);//czekaj na gotowosc wpisania polecenia  
	lcd_write_cmd(cmd);//zapisz polecenie
}
//zapisanie polecenia z 1 argumentem 
void lcd_write_1cmd(unsigned char arg, unsigned char cmd){
 	while((lcd_read_status()&3)!=3);//czekaj na gotowosc wpisania danej
	lcd_write_data(arg);//zapisz argument1
	while((lcd_read_status()&3)!=3);//czekaj na gotowosc wpisania polecenia  
	lcd_write_cmd(cmd);//zapisz polecenie
}
//zapisanie polecenia z 2 argumentami 
void lcd_write_2cmd(unsigned char arg1, unsigned char arg2, unsigned char cmd){
 	while((lcd_read_status()&3)!=3);//czekaj na gotowosc wpisania danej
	lcd_write_data(arg2);//zapisz argument1
	while((lcd_read_status()&3)!=3);//czekaj na gotowosc wpisania danej
	lcd_write_data(arg1);//zapisz argument2
	while((lcd_read_status()&3)!=3);//czekaj na gotowosc wpisania polecenia  
	lcd_write_cmd(cmd);//zapisz polecenie
}
//***************************************************************
//PROCEDURY SPRZETOWE
//***************************************************************
//inicjalizacja linii drivera
void lcd_hwd_init(void){
int i;
	for(i=0;i<10000;i++)
	delay();
	IO1DIR|=0x00f80000;//linie sterujace jako wyjscia
	IOCLR1=0;
	IOCLR1|=RES;//reset wyswietlacza aktywny
	for(i=0;i<8000;i++)
	delay();
	IOSET1|=RES;//reset nieaktywny
	IOSET1=0;
	IOSET1|=WR;//te linie w stan wysoki
	IOSET1|=RD;
	IOSET1|=CD;
	IOSET1|=CE;
}
//zapisanie danej do sterownika 
void lcd_write_data(unsigned char data){
 	IOCLR1|=CD;	delay();//linia CD=0 - zapisanie danej
	IOSET1|=RD; delay();//linia RD=1 
	wr_lcd_bus(data);//zapisanie na magistrale
}
//zapisanie komendy do sterownika
void lcd_write_cmd(unsigned char cmd){
 	 IOSET1|=CD;	delay();//linia CD=1 - zapisanie komendy 
	 IOSET1|=RD;    delay();//linia RD=1 
	 wr_lcd_bus(cmd);//zapisanie na magistrale
}
//odczytanie danej z magistrali
unsigned char lcd_read_data(void){
 	 IOCLR1|=CD;	delay();//linia CD=0 - odczytanie danej
	 IOSET1|=WR; 	delay();//WR=1 
	 return(rd_lcd_bus());
}
//odczytanie statusu z magistrali
unsigned char lcd_read_status(void){
 	 IOSET1|=CD;	delay();//linia CD=1 - odczytanie satusu 
	 IOSET1|=WR; delay();//WR=1
	 return(rd_lcd_bus());
}
//odczytanie danych z magistrali
unsigned char rd_lcd_bus(void){
unsigned char data;
 	 IO0DIR&=0xff00ffff;//bity P0.16....P023 wejscie
	 IOCLR1|=CE; delay();//linia CE=0
	 IOCLR1|=RD; delay();  delay();
	 data=(IOPIN0>>16);//odczytaj dane 
	 IOSET1|=RD; delay();//RD=1
	 IOSET1|=CE; delay();//CE=1
	 return(data);
}
//zapisanie danej na magistrale 
//linie danych P0.16...P0.23
//!WR=P1.23, !RD=P1.22, !CE=P1.21, !C/D=P1.20
void wr_lcd_bus(unsigned char data){
	IO0DIR|=(0xff<<16);//bity P0.16....P023 wyjscie
	int temp=(data<<16);
	IOCLR0=0x00ff0000;//zeruj bity P0.16...P0.23
	delay();
	IOSET0=temp;//dane na swoim miejscu	
	delay();
	IOCLR1|=CE; delay();//linia CE=0
	IOCLR1|=WR; delay();  delay();  delay();//WR=0 - zapisanie danej
	IOSET1|=WR; delay();//WR=1
	IOSET1|=CE; delay();//CE=1
}
void delay (void){ 
  unsigned int i;  
  for(i = 0; i < 0x10; i++);	   
}



						