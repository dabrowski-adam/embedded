#include <LPC214x.H>
#include "t6963.h"
extern const unsigned char faza1[];
extern const unsigned char faza2[];
extern const unsigned char faza3[];
extern const unsigned char faza4[];
extern const unsigned char play[];
extern const unsigned char screen[];
extern const unsigned char wsk[];
extern const unsigned char Char_gen[];
void anim_play(char x,char y, int del ){
int i;
		send_icon_ram(faza1,x,y);
		for(i=0;i<del;i++)
		delay();
		send_icon_ram(faza2,x,y);
		for(i=0;i<del;i++)
		delay();
		send_icon_ram(faza3,x,y);
		for(i=0;i<del;i++)
		delay();
		send_icon_ram(faza4,x,y);
		for(i=0;i<del;i++)
		delay();
}
void anim_fwd(char x,char y, int del ){
int i;
		send_icon_ram(faza4,x,y);
		for(i=0;i<del;i++)
		delay();
		send_icon_ram(faza3,x,y);
		for(i=0;i<del;i++)
		delay();
		send_icon_ram(faza2,x,y);
		for(i=0;i<del;i++)
		delay();
		send_icon_ram(faza1,x,y);
		for(i=0;i<del;i++)
		delay();
}
//wpisywanie do VRAM znak�w 0...9 z generatora w Char_gen
void send_char_ram(char cyfra, char x, char y)
{
char i;
const unsigned char *char_gen;
int point;
    char_gen=Char_gen;
	char_gen+=cyfra*8;//pozycja w buforze generatora
	point=GA;//poczatek obszaru VRAM grafiki
	point+=x;//offset w poziomie
	point+=y*30;//offset w pionie
	lcd_write_2cmd(point>>8,point,0x24);//address pointer set 
	lcd_write_0cmd(0xb0);//data auto write
	for(i=0;i<8;i++){
	while((lcd_read_status()&8)!=8);//czekaj na gotowosc wpisania danej
	lcd_write_data(*char_gen++);
	lcd_write_0cmd(0xb3);//reset auto write
	point=point+30;
	lcd_write_2cmd((point>>8),point,0x24);//address pointer set
	lcd_write_0cmd(0xb0);//data auto write 	
	}
	lcd_write_0cmd(0xb3);//reset auto write

}
//wpisywanie do VRAM bitmapy 
void send_icon_ram(const unsigned char *buffer,char x,char y){
char i,j,iz,jz;
int point;
	iz=*buffer++;
	jz=*buffer++;
	point=GA;//poczatek obszaru VRAM grafiki
	point+=x;//offset w poziomie
	point+=y*30;//offset w pionie
	lcd_write_2cmd(point>>8,point,0x24);//address pointer set 
	lcd_write_0cmd(0xb0);//data auto write
	for(i=0;i<iz;i++){
	for(j=0;j<jz;j++){ 
	 while((lcd_read_status()&8)!=8);//czekaj na gotowosc wpisania danej
	lcd_write_data(*buffer++);
	++point;
	}
	lcd_write_0cmd(0xb3);//reset auto write
	point=point+(30-jz);
	lcd_write_2cmd((point>>8),point,0x24);//address pointer set
	lcd_write_0cmd(0xb0);//data auto write 
	}//end (for i=0......
	lcd_write_0cmd(0xb3);//reset auto write
}
