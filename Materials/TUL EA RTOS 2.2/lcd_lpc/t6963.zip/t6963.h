#include <LPC214x.H>
//definicja linii sterujacych
#define WR (1<<23)
#define RD (1<<22)
#define CE (1<<21)
#define CD (1<<20)
#define RES (1<<19)
#define TA 0x1800 //adres poczatkowy obszaru tekstu
#define GA 0x0000 //adres poczatkowy obszaru grafiki
void send_graph_ram(const unsigned char buffer[][30]);
void display_text(const char *buffer,char x, char y);
void init_text_ram(void);//zerowanie obszaru VRAM dla txt
void init_graph_ram(char fill);//inicjowanie obszaru VRAM dla grafiki
void lcd_init(void);//inicjalizacja wyswietlacza 
void lcd_write_0cmd(unsigned char cmd);//komenda bez arg
void lcd_write_1cmd(unsigned char arg, unsigned char cmd);//komenda 1 arg 
void lcd_write_2cmd(unsigned char arg1, unsigned char arg2, unsigned char cmd);//komenda z 2 arg
void lcd_hwd_init(void);//inicjaja linii magistrali
void wr_lcd_bus(unsigned char data);//zapisanie danej (polecenia) do sterownika	LCD
unsigned char rd_lcd_bus(void);//odczytanie danej (statusu) z magistrali sterownika LCD
void lcd_write_data(unsigned char data);//zapisanie danej do sterownika
unsigned char lcd_read_data(void);//odczyt danej ze sterownika
void lcd_write_cmd(unsigned char cmd);//zapisanie komendy do sterownika
unsigned char lcd_read_status(void);//odczytanie statusu ze sterownika
void delay (void);

void send_icon_ram(const unsigned char *buffer,char x,char y);//zapisanie do VRAM bitmapy
void send_char_ram(char cyfra, char x, char y);
void anim_play(char x, char y, int del);//animacja grajacego magnetofonu
void anim_fwd(char x,char y, int del );
void init_CGRAM(void);
void display_char(char ram_char, char x, char y);
