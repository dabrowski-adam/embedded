#include <LPC214x.H>
#include "nokia.h"

#define PIXEL_OFF  0
#define PIXEL_ON   1
#define PIXEL_XOR  2
static unsigned char  DisplayRam [512];//RAM wyswietlacza w mikrokontrolerze
int LoRAM, HiRAM, IdxRAM;//wskazniki pamieci RAM 

//wyliczenie indeksu w pamieci RAM na podstawie pozycji x ( 0...5 wiersz) 
//i pozycji y (0...83 kolumna)
void JumpXY (char x, char y )
{
    IdxRAM = x*6 + y*84;
}
//zerowanie pamieci RAM mikrokontrolera
void DisplayRAMClear(void)
{
int i;

    for ( i = 0; i < 512; i++ )
    {
        DisplayRam[i]=0x00;
    }

    LoRAM = 0;//poczatek obszaru do przepisania do wyswietlacza
    HiRAM = 511;//koniec obszaru do przepisania do wyswietlacza
	LcdUpdate();
}
//przepisanie DisplayRAM do RAM wyswietlacza 
void LcdUpdate(void )
{
int i;

	//korekcja wskaznikow 
    if ( LoRAM < 0 )
        LoRAM = 0;
    else 
	if ( LoRAM >= 512 )
        LoRAM = 511;

    if ( HiRAM< 0 )
        HiRAM= 0;
    else 
	if ( HiRAM >= 512 )
        HiRAM=511;

	IOCLR0|=SCE;//SCE=0
	IOCLR0|=DC;//DC=0 wpisywanie komend
	WriteSPI((LoRAM/84)|0x40);//ustawienie licznika wierszy
	WriteSPI((LoRAM%84)|0x80);//ustawienie licznika kolumn
	IOSET0|=SCE;//SCE=1

	IOSET0|=DC;//DC=1;
	IOCLR0|=SCE;//SCE=0
    
    for ( i = LoRAM; i <= HiRAM; i++ )
       WriteSPI(DisplayRam[i]);//przepisanie DiplayRAM do RAM wyswietlacza

   IOSET0|=SCE;//SCE=1

    LoRAM= 511;
    HiRAM = 0;
}

void LcdPixel (char x, char y, char PixelMode )
{
int  index;
unsigned char  offset;
unsigned char  data;

    if (x>84) return;
    if (y>48) return;

    index = ((y / 8) * 84) + x;
    offset  = y - ((y / 8) * 8);

    data = DisplayRam[index];

    if (PixelMode==PIXEL_OFF)
        data &= (~(0x01 << offset));
    else 
	if(PixelMode==PIXEL_ON )
        data |= (0x01 << offset);
    else 
	if(PixelMode==PIXEL_XOR)
        data ^= (0x01 << offset);
  

    DisplayRam[index]=data;
    if (index<LoRAM )
        LoRAM= index;
    if ( index > HiRAM)
        HiRAM = index;
}
void LcdLine (char x1,char y1,char x2,char y2,char PixelMode)
{
int dx, dy, stepx, stepy, fraction;

    dy = y2 - y1;
    dx = x2 - x1;

    if ( dy < 0 )
    {
        dy    = -dy;
        stepy = -1;
    }
    else
    {
        stepy = 1;
    }

    if ( dx < 0 )
    {
        dx    = -dx;
        stepx = -1;
    }
    else
    {
        stepx = 1;
    }

    dx <<= 1;
    dy <<= 1;

    LcdPixel( x1, y1, PixelMode );

    if ( dx > dy )
    {
        fraction = dy - (dx >> 1);
        while ( x1 != x2 )
        {
            if ( fraction >= 0 )
            {
                y1 += stepy;
                fraction -= dx;
            }
            x1 += stepx;
            fraction += dy;
            LcdPixel( x1, y1, PixelMode );
        }
    }
    else
    {
        fraction = dx - (dy >> 1);
        while ( y1 != y2 )
        {
            if ( fraction >= 0 )
            {
                x1 += stepx;
                fraction -= dy;
            }
            y1 += stepy;
            fraction += dx;
            LcdPixel( x1, y1, PixelMode );
        }
    }
    LcdUpdate();
}


