#include <LPC214x.H>
#include "nokia.h"
extern const unsigned char bmp[];

int main(void){
	init_lcd_hwd();
	IOCLR0|=RES;//RES=0
	delay();delay();
	IOSET0|=RES;//RES=1

	InitDisNok();
	DisplayRAMClear();

	
	DispLcd("Wyswietlacz od",0,0);
	DispLcd("telefonu Nokia",0,1);
	DispLcd("    3310      ",0,2);
	DispLcd("tryb znakowy  ",0,3);
	DispLcd("  znaki 5x7   ",0,4);
	DispLcd("   pikseli    ",0,5);	
WriteBmp(bmp);

	while(1);	
}
void InitDisNok(void)
{
int i;
	IOCLR0|=SCE;//SCE=0
	IOCLR0|=DC;
	WriteSPI(0x21);//komendy rosrzerzone
	WriteSPI(0xc8);//Ustawienie Vop
	WriteSPI(0x06);//korekcja tempertury
	WriteSPI(0x13);//wsp�lczynnik multipleksowania
	WriteSPI(0x20);//komendy standardowe - adresowanie poziome
	WriteSPI(0x0c);// tyb wy�wietlania stndard mode
	WriteSPI(0x40);//zerowanie licznika wierszy
	WriteSPI(0x80);//zerowanie licznika kolumn
	IOSET0|=DC;//DC=1;
	IOSET0|=SCE;//SCE=1
	IOCLR0|=SCE;//SCE=0
	for(i=0;i<504;i++)
	WriteSPI(0xaa);//zerowanie pamieci RAM wyswietlacza
	IOSET0|=SCE;//SCE=1
}

//wyswietla ciag zankow ascii
void DispLcd(const char *napis,char x,char y)
{	
	Poz(x,y);//pozycja tekstu na wyswietlaczu
	IOSET0|=DC;
    while(*napis!=0)	
	{WriteChar(*napis);
    ++napis;}
} 
//ustawia pozycje wyswietlania (14 kolumn, 6 wierszy)
void Poz(char x, char y)
{
	x=x*6;
	IOCLR0|=SCE;//SCE=0
	IOCLR0|=DC;//DC=0 wpisywanie komend
	WriteSPI(y|0x40);//zerowanie licznika wierszy
	WriteSPI(x|0x80);//zerowanie licznika kolumn
	IOSET0|=SCE;//SCE=1
}
//wyswietlenie zaku ascii 8x6 pixeli
void WriteChar(char code)
{
int code_point;
	IOSET0|=DC;//DC=1
	code_point=((int)code*6);
	IOCLR0|=SCE;//SCE=0
	WriteSPI(rom_gen[code_point++]);
	WriteSPI(rom_gen[code_point++]);
	WriteSPI(rom_gen[code_point++]);
	WriteSPI(rom_gen[code_point++]);
	WriteSPI(rom_gen[code_point++]);
	WriteSPI(rom_gen[code_point]);
	IOSET0|=SCE;//SCE=1
}

void WriteBmp(const unsigned char *buffer)
{
int i,j,k;
	IOCLR0|=SCE;//SCE=0
	IOCLR0|=DC;//DC=0
	WriteSPI(0x40);//zerowanie licznika wierszy
	WriteSPI(0x80);//zerowanie licznika kolumn
	IOSET0|=DC;//DC=1
	IOCLR0|=SCE;//SCE=0
	k=i=0;
	for(i=0;i<6;i++){
	for(j=k;j<k+83;j++)
	WriteSPI(*buffer++);	
	k=k+44;//korekcja bitmapy 
	buffer+=44;
	}
	IOSET0|=SCE;//SCE=1
}
void WriteSPI(unsigned char data){
char status;
	S0SPDR=data;
	while((S0SPSR&0x80)==0);//czekaj na ustawienie SPIF
	status=S0SPSR;

}
void init_lcd_hwd(void){
	
	IO0DIR|=SSEL_OUT;//SSEL1 wyjscie
	IOSET0|=SSEL_OUT;//SSEL1 stan wysoki

	IO0DIR|=DC;//C/D wyjscie
	IOSET0|=DC;//SSEL1 stan wysoki
	IO0DIR|=SCE;//SCE wyjscie
	IOSET0|=SCE;//SSEL1 stan wysoki
	IO0DIR|=RES;//RES wyjscie
	IOSET0|=RES;//SSEL1 stan wysoki
	PINSEL0=0x000001540;//przypisanie  linii portu do SPI0
	S0SPCCR=16;//predkosc na SPI
	S0SPCR=0x0020;//SPI1 Master
}
void delay (void){ 
  unsigned int i;  
  for(i = 0; i < 0x10; i++);	   
}

