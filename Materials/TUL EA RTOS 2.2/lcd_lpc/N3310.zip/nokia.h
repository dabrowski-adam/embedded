#define MISO1 1<<6
#define SCK1 1<<4
#define SSEL1 1<<7
#define SSEL_OUT 1<<3
#define DC 1<<8
#define SCE 1<<9
#define RES 1<<10
extern const char rom_gen[];
void init_lcd_hwd(void);//inicjalizacja interfejsu LCD 
void WriteSPI(unsigned char data);
void InitDisNok(void);
void delay (void);
void WriteChar(char code);
void Poz(char x, char y);
void DispLcd(const char *napis,char x,char y);
void WriteBmp(const unsigned char *buffer);
void LcdUpdate(void);
void DisplayRAMClear(void);
void LcdPixel (char x, char y, char PixelMode);
void LcdLine (char x1,char y1,char x2,char y2,char PixelMode);
