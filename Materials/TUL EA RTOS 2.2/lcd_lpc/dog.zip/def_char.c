#include "dog.h"
const unsigned char GenChar[] = {
0x00,0x0e,0x01,0x0f,0x11,0x0f,0x04,0x00};

void user_char(void)
{
unsigned char i; 
	lcd_write_cmd(0x38);//function set
	lcd_write_cmd(0x40);//adres zerowy CGRAM
	for(i=0;i<8;i++)
	lcd_write_data(GenChar[i]);
	lcd_write_cmd(0x80);//adres zerowy DDRAM
}
