#include "dog.h"

int main (void){
	lcd_hwd_init();
	lcd_init();
	DispLcd("Wyswietlacz",0,2);
	DispLcd("EA  DOGM163",1,2);
	DispLcd("3x16 znakow",2,2);
	while(1);
}
void lcd_init(void){
 	lcd_write_cmd(0x39);//function set
	lcd_write_cmd(0x15);//bias set 1/5bias 3linie

	lcd_write_cmd(0x54);//power control

	lcd_write_cmd(0x6e);//follower control
	lcd_write_cmd(0x7b);//contrast set

	lcd_write_cmd(0x0c);//display on cursor on blink on

	lcd_write_cmd(1);//cls
	lcd_write_cmd(6);//cursor auto increment
}
void lcd_hwd_init(void){
int i;
	for(i=0;i<1000;i++)
	delay();
	IO1DIR=0x00FF0000;//linie sterujace jako wyjscia
	IOCLR1=0;
	IOSET1=0;
	IOCLR1|=E;
	IOSET1|=RW;
	IOSET1|=RS;
}
void lcd_write_data(unsigned char data){
	while((lcd_read_status()&0x80)==0x80);
  	IOSET1|=RS;//RS=1 zapisywanie pamieci
	lcd_bus_write(data);
}
void lcd_write_cmd(unsigned char cmd){
	while((lcd_read_status()&0x80)==0x80);
	IOCLR1|=RS;//RS=0 wysylanie komend	
	lcd_bus_write(cmd);
}
unsigned char lcd_read_status(void)
{
	   IOCLR1|=RS;//czytanie statusu
	   return(lcd_bus_read());	
}
void lcd_bus_write(unsigned char data)
{
 	IOCLR1|=E;delay();//E=0;
	IOCLR1|=RW;delay();//RW=0 zapisywanie
	IOSET1|=E; delay();//E=1
	IO0DIR|=(0xff<<16);//bity P0.16....P023 wyjscie
	int temp=(data<<16);
	IOCLR0=0x00ff0000;delay();//zeruj bity P0.16...P0.23
	IOSET0=temp;delay();//dane na swoim miejscu	
	IOCLR1|=E;delay();//E=0;
}
unsigned char lcd_bus_read(void){
unsigned char data;
	IO0DIR&=0xff00ffff;//bity P0.16....P023 wejscie
	IOCLR1|=E;delay();//E=0;
	IOSET1|=RW;delay();//RW=1 odczytywanie
	IOSET1|=E; delay();//E=1  
	data=(IOPIN0>>16);//odczytaj dane 
	IOCLR1|=E;delay();//E=0;
	return(data);
}
void DispLcd(const char *napis,char lin,char pos)
{
unsigned char add=0;	
	if(lin>2||pos>15)
	return;
	if(lin==0)
	add=pos;
	else
	if(lin==1)
	add=pos|0x10;
	else
	if(lin==2)
	add=pos|0x20;
    lcd_write_cmd(add|0x80);//set DDRAM address			
    while(*napis!=0)	
	{lcd_write_data(*napis);
    ++napis;}
} 
void delay (void){ 
  unsigned int i;  
  for(i = 0; i < 0x10; i++);	   
}

