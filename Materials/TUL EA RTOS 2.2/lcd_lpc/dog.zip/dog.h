#include <LPC214x.h>
//definicje linii sterujacych
#define E 1<<16
#define RW 1<<17
#define RS 1<<18
#define RES 1<<19

void delay (void);
void lcd_hwd_init(void);
void lcd_init(void);
void lcd_write_cmd(unsigned char cmd);
void lcd_bus_write(unsigned char data);
unsigned char lcd_read_status(void);
unsigned char lcd_bus_read(void);
void lcd_write_data(unsigned char data);
void DispLcd(const char *napis,char lin,char pos);
void user_char(void);
