#include <LPC214x.H>
#include "hdr.h"
int main(void){
int i,j;
	
	
	SCS=0;
	oled_hwd_init();

	oled_init();
	//oled_write_cmd(0xa4);//display on 
//	while(1);
	    oled_write_cmd(0);//set lower column address
	    oled_write_cmd(0x10);//set higer column address
		for(j=0;j<8;j++)
		{oled_write_cmd(0xb0+j);
		for(i=0;i<132;i++)
		oled_write_data(0);}
		
	
		send_bmp();
		while(1);
		DispLcd(" Test wyswietlacza ",0,1);
		DispLcd("HANTRONIX HDR12864 ",0,2);
		DispLcd("matryca OLED 128x64",0,3);
		DispLcd(" sterownik SSD1303",0,4);
		DispLcd("   Tryb tekstowy  ",0,5);
		DispLcd(" znaki 6x8 pikseli",0,6);
		oled_write_cmd(0);//set lower column address
	    oled_write_cmd(0x10);//set higer column address

		


		
	while(1);
}
void oled_init(void){
	oled_write_cmd(0);//set lower column address
	oled_write_cmd(0x10);//set higer column address
	//oled_write_cmd(0x2f);//set higer column address

	oled_write_cmd(0x40);//set display start line
	oled_write_cmd(0x81);//set contrast control 
	oled_write_cmd(0x2f);
	oled_write_cmd(0xa0);//column address
	oled_write_cmd(0xb0);//1st bank RAM
	oled_write_cmd(0xa4);//display on 
	oled_write_cmd(0xa6);//normal display
	//oled_write_cmd(0xa8);//set multiplex ratio 
	//oled_write_cmd(0x28);//48mux


	oled_write_cmd(0xad);//set DC-DC
	oled_write_cmd(0x8b);//8a OFF 8b ON
	oled_write_cmd(0xaf);//set display on/off AF ON AE OFF

	oled_write_cmd(0xd3);//set dispaly offset
	oled_write_cmd(0x00);//no offset

	oled_write_cmd(0xd5);//set clock divide
	oled_write_cmd(0x70);//clock 100hz
	oled_write_cmd(0xa0);//0xa0
	oled_write_cmd(0xd8);//set color on/off
	oled_write_cmd(0x00);//mono color
	oled_write_cmd(0xda);//pins hardware 
	oled_write_cmd(0x12);//0x12
	oled_write_cmd(0xdb);//set VCOMH
	oled_write_cmd(0x35);//0x35
	oled_write_cmd(0xd9);//d9 set proecharge period
	oled_write_cmd(0x22);//P1=2, P2=2
	oled_write_cmd(0xc8);//c0 COM0


}
//***************************************************************
//PROCEDURY SPRZETOWE
//***************************************************************
//inicjalizacja linii drivera
void oled_hwd_init(void){
int i;
	for(i=0;i<100;i++)
	delay();
	IO1DIR=0x00FF0000;//linie sterujace jako wyjscia
	IOCLR1=0;

	IOSET1=0;
	IOSET1|=WR;//te linie w stan wysoki
	delay();
	IOSET1|=RD;
	IOSET1|=CD;
	IOSET1|=CE;
	IOSET1|=DISB;
	IOCLR1|=RES;//reset wyswietlacza aktywny
	for(i=0;i<8000;i++)
	delay();
	IOSET1|=RES;//reset nieaktywny
	//IOCLR1|0x00ff0000;
	//IOSET1|=0x00aa0000;
}
//zapisanie danej do sterownika 
void oled_write_data(unsigned char data){
 	IOSET1|=CD;	delay();//linia CD=1 - zapisanie danej
	IOSET1|=RD; delay();//linia RD=1 
	wr_oled_bus(data);//zapisanie na magistrale
}
//zapisanie komendy do sterownika
void oled_write_cmd(unsigned char cmd){
     
 	 IOCLR1|=CD;	delay();//linia CD=0 - zapisanie komendy 
	 IOSET1|=RD;    delay();//linia RD=1 
	 wr_oled_bus(cmd);//zapisanie na magistrale
}
//odczytanie danej z magistrali
unsigned char oled_read_data(void){
 	 IOCLR1|=CD;	delay();//linia CD=0 - odczytanie danej
	 IOSET1|=WR; 	delay();//WR=1 
	 return(rd_oled_bus());
}
//odczytanie statusu z magistrali
unsigned char oled_read_status(void){
 	 IOSET1|=CD;  delay();//linia CD=1 - odczytanie satusu 
	 IOSET1|=WR;  delay();//WR=1
	 return(rd_oled_bus());
}
//odczytanie danych z magistrali
unsigned char rd_oled_bus(void){
unsigned char data;
 	 IO0DIR&=0xff00ffff;//bity P0.16....P023 wejscie
	 IOCLR1|=CE; delay();//linia CE=0
	 IOCLR1|=RD; delay();  delay();
	 data=(IOPIN0>>16);//odczytaj dane 
	 IOSET1|=RD; delay();//RD=1
	 IOSET1|=CE; delay();//CE=1
	 return(data);
}
//zapisanie danej na magistrale 
//linie danych P0.16...P0.23
//!WR=P1.23, !RD=P1.22, !CE=P1.21, !C/D=P1.20
void wr_oled_bus(unsigned char data){
	IOSET1|=CE; delay();//CE=1
	IO0DIR|=(0xff<<16);//bity P0.16....P023 wyjscie
	//IO0DIR|=0x00FF0000;//linie sterujace jako wyjscia
	int temp=(data<<16);
	IOCLR0=0x00ff0000;//zeruj bity P0.16...P0.23
	delay();
	IOSET0=temp;//dane na swoim miejscu	
	delay();
	IOCLR1|=CE; delay();//linia CE=0
	IOCLR1|=WR; delay();  delay();  delay();//WR=0 - zapisanie danej
	IOSET1|=WR; delay();//WR=1
	IOSET1|=CE; delay();//CE=1
}
extern const unsigned char bmp[];
void send_bmp(void){
unsigned char i,j;
	oled_write_cmd(0);//set lower column address
	    oled_write_cmd(0x10);//set higer column address
		for(j=0;j<8;j++){
		oled_write_cmd(0xb0+j);//set page 
		for(i=0;i<132;i++)
		oled_write_data(bmp[i+j*128]);
		}
		oled_write_cmd(0);//set lower column address
	    oled_write_cmd(0x10);//set higer column address
		oled_write_cmd(0x40);//set display start line
}
void delay (void){ 
  unsigned int i;  
  for(i = 0; i < 0x20; i++);	   
}



