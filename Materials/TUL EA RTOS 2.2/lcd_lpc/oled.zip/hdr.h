//definicja linii sterujacych
#define WR (1<<17)
#define RD (1<<18)
#define CE (1<<19)
#define CD (1<<16)
#define RES (1<<20)
#define DISB (1<<21)
void oled_hwd_init(void);
void oled_write_data(unsigned char data);
void oled_write_cmd(unsigned char cmd);
unsigned char oled_read_data(void);
unsigned char oled_read_status(void);
unsigned char rd_oled_bus(void);
void wr_oled_bus(unsigned char data);
void delay (void);
void oled_init(void);
void WriteChar(char code);
void DispLcd(const char *napis,char x,char y);
void Poz(char x, char y);
void send_bmp(void);

